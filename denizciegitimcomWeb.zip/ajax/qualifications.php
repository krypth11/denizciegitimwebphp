<?php
header('Content-Type: application/json; charset=utf-8');

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/community_helper.php';
require_once '../api/v1/mock_exam_helper.php';

try {
    $user = require_admin();
} catch (Throwable $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Bu işlem için yetkiniz bulunmuyor.',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    switch ($action) {
        case 'list':
            $sql = 'SELECT q.*, COALESCE(COUNT(DISTINCT qq.id), 0) AS total_question_count
                    FROM qualifications q
                    LEFT JOIN courses c ON c.qualification_id = q.id
                    LEFT JOIN questions qq ON qq.course_id = c.id
                    GROUP BY q.id
                    ORDER BY q.order_index, q.name';
            $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: [];
            echo json_encode([
                'success' => true,
                'data' => $rows,
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'get_breakdown':
            $qualificationId = trim((string)($_GET['qualification_id'] ?? ''));
            if ($qualificationId === '') {
                echo json_encode(['success' => false, 'message' => 'qualification_id gerekli!'], JSON_UNESCAPED_UNICODE);
                break;
            }

            $qStmt = $pdo->prepare('SELECT id FROM qualifications WHERE id = ? LIMIT 1');
            $qStmt->execute([$qualificationId]);
            if (!$qStmt->fetchColumn()) {
                echo json_encode(['success' => false, 'message' => 'Yeterlilik bulunamadı!'], JSON_UNESCAPED_UNICODE);
                break;
            }

            $courseStmt = $pdo->prepare('SELECT c.id, c.name, c.order_index,
                                                COALESCE(COUNT(DISTINCT qs.id),0) AS question_count,
                                                COALESCE(COUNT(DISTINCT CASE WHEN (qs.topic_id IS NULL OR qs.topic_id = \'\') THEN qs.id END),0) AS unassigned_question_count
                                         FROM courses c
                                         LEFT JOIN questions qs ON qs.course_id = c.id
                                         WHERE c.qualification_id = ?
                                         GROUP BY c.id
                                         ORDER BY c.order_index ASC, c.name ASC');
            $courseStmt->execute([$qualificationId]);
            $courses = $courseStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

            $topicStmt = $pdo->prepare('SELECT t.id, t.name, t.course_id, t.order_index, COALESCE(COUNT(DISTINCT q.id),0) AS question_count
                                        FROM topics t
                                        LEFT JOIN questions q ON q.topic_id = t.id
                                        INNER JOIN courses c ON c.id = t.course_id
                                        WHERE c.qualification_id = ?
                                        GROUP BY t.id
                                        ORDER BY t.order_index ASC, t.name ASC');
            $topicStmt->execute([$qualificationId]);
            $topics = $topicStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

            $topicsByCourse = [];
            foreach ($topics as $topic) {
                $cid = (string)$topic['course_id'];
                $topicsByCourse[$cid][] = [
                    'id' => (string)$topic['id'],
                    'name' => (string)$topic['name'],
                    'question_count' => (int)$topic['question_count'],
                ];
            }

            $resultCourses = [];
            foreach ($courses as $course) {
                $cid = (string)$course['id'];
                $resultCourses[] = [
                    'id' => $cid,
                    'name' => (string)$course['name'],
                    'question_count' => (int)$course['question_count'],
                    'unassigned_question_count' => (int)$course['unassigned_question_count'],
                    'topics' => $topicsByCourse[$cid] ?? [],
                ];
            }

            echo json_encode([
                'success' => true,
                'qualification_id' => $qualificationId,
                'courses' => $resultCourses,
            ], JSON_UNESCAPED_UNICODE);
            break;

        case 'add':
            $name = sanitize_input($_POST['name'] ?? '');
            $description = sanitize_input($_POST['description'] ?? '');
            $order_index = (int)($_POST['order_index'] ?? 0);
            $is_active = (int)($_POST['is_active'] ?? 1) === 1 ? 1 : 0;

            if ($name === '') {
                echo json_encode([
                    'success' => false,
                    'message' => 'İsim alanı zorunludur!',
                ], JSON_UNESCAPED_UNICODE);
                break;
            }

            $id = generate_uuid();
            $stmt = $pdo->prepare('INSERT INTO qualifications (id, name, description, order_index, is_active, created_at) VALUES (?, ?, ?, ?, ?, NOW())');
            $result = $stmt->execute([$id, $name, $description, $order_index, $is_active]);

            if ($result) {
                try {
                    mock_exam_ensure_qualification_exam_settings($pdo, $id);
                } catch (Throwable $ensureError) {
                    error_log('Qualification exam settings ensure add failed: ' . $ensureError->getMessage());
                }

                try {
                    community_sync_qualification_room($pdo, $id, $name, $is_active === 1);
                } catch (Throwable $syncError) {
                    error_log('Qualification room sync add failed: ' . $syncError->getMessage());
                }

                echo json_encode([
                    'success' => true,
                    'message' => 'Yeterlilik başarıyla eklendi!',
                    'data' => ['id' => $id],
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Veritabanı hatası: Ekleme başarısız',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'get':
            $id = $_GET['id'] ?? '';

            if ($id === '') {
                echo json_encode([
                    'success' => false,
                    'message' => 'ID parametresi gerekli!',
                ], JSON_UNESCAPED_UNICODE);
                break;
            }

            $stmt = $pdo->prepare('SELECT * FROM qualifications WHERE id = ? LIMIT 1');
            $stmt->execute([$id]);
            $data = $stmt->fetch();

            if ($data) {
                echo json_encode([
                    'success' => true,
                    'data' => $data,
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Kayıt bulunamadı!',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'update':
            $id = $_POST['id'] ?? '';
            $name = sanitize_input($_POST['name'] ?? '');
            $description = sanitize_input($_POST['description'] ?? '');
            $order_index = (int)($_POST['order_index'] ?? 0);
            $is_active = (int)($_POST['is_active'] ?? 1) === 1 ? 1 : 0;

            if ($id === '' || $name === '') {
                echo json_encode([
                    'success' => false,
                    'message' => 'ID ve isim alanları zorunludur!',
                ], JSON_UNESCAPED_UNICODE);
                break;
            }

            $stmt = $pdo->prepare('UPDATE qualifications SET name = ?, description = ?, order_index = ?, is_active = ? WHERE id = ?');
            $result = $stmt->execute([$name, $description, $order_index, $is_active, $id]);

            if ($result) {
                try {
                    mock_exam_ensure_qualification_exam_settings($pdo, $id);
                } catch (Throwable $ensureError) {
                    error_log('Qualification exam settings ensure update failed: ' . $ensureError->getMessage());
                }

                try {
                    community_sync_qualification_room($pdo, $id, $name, $is_active === 1);
                } catch (Throwable $syncError) {
                    error_log('Qualification room sync update failed: ' . $syncError->getMessage());
                }

                echo json_encode([
                    'success' => true,
                    'message' => 'Yeterlilik başarıyla güncellendi!',
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Güncelleme başarısız!',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'toggle_active':
            $id = trim((string)($_POST['id'] ?? ''));
            $rawIsActive = $_POST['is_active'] ?? null;

            if ($id === '') {
                echo json_encode([
                    'success' => false,
                    'message' => 'ID parametresi gerekli!',
                ], JSON_UNESCAPED_UNICODE);
                break;
            }

            if (!in_array((string)$rawIsActive, ['0', '1'], true)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'is_active sadece 0 veya 1 olabilir.',
                ], JSON_UNESCAPED_UNICODE);
                break;
            }

            $isActive = (int)$rawIsActive;

            $nameStmt = $pdo->prepare('SELECT name FROM qualifications WHERE id = ? LIMIT 1');
            $nameStmt->execute([$id]);
            $qualificationName = (string)($nameStmt->fetchColumn() ?: 'Yeterlilik Odası');

            if ($qualificationName === '') {
                echo json_encode([
                    'success' => false,
                    'message' => 'Kayıt bulunamadı!',
                ], JSON_UNESCAPED_UNICODE);
                break;
            }

            $stmt = $pdo->prepare('UPDATE qualifications SET is_active = ? WHERE id = ?');
            $result = $stmt->execute([$isActive, $id]);

            if ($result) {
                try {
                    community_sync_qualification_room($pdo, $id, $qualificationName, $isActive === 1);
                } catch (Throwable $syncError) {
                    error_log('Qualification room sync toggle failed: ' . $syncError->getMessage());
                }

                echo json_encode([
                    'success' => true,
                    'message' => 'Yeterlilik durumu güncellendi.',
                    'is_active' => $isActive,
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Durum güncelleme başarısız!',
                    'is_active' => $isActive,
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'delete':
            $id = $_POST['id'] ?? '';

            if ($id === '') {
                echo json_encode([
                    'success' => false,
                    'message' => 'ID parametresi gerekli!',
                ], JSON_UNESCAPED_UNICODE);
                break;
            }

            $checkStmt = $pdo->prepare('SELECT COUNT(*) as count FROM courses WHERE qualification_id = ?');
            $checkStmt->execute([$id]);
            $count = (int)($checkStmt->fetch()['count'] ?? 0);

            $existingNameStmt = $pdo->prepare('SELECT name FROM qualifications WHERE id = ? LIMIT 1');
            $existingNameStmt->execute([$id]);
            $existingQualificationName = (string)($existingNameStmt->fetchColumn() ?: 'Yeterlilik Odası');

            if ($count > 0) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Bu yeterliğe ait ' . $count . ' ders var! Önce dersleri silin.',
                ], JSON_UNESCAPED_UNICODE);
                break;
            }

            try {
                $cleanupStmt = $pdo->prepare('DELETE FROM qualification_exam_settings WHERE qualification_id = ?');
                $cleanupStmt->execute([$id]);
            } catch (Throwable $cleanupError) {
                error_log('Qualification exam settings cleanup delete failed: ' . $cleanupError->getMessage());
            }

            $stmt = $pdo->prepare('DELETE FROM qualifications WHERE id = ?');
            $result = $stmt->execute([$id]);

            if ($result) {
                try {
                    community_sync_qualification_room($pdo, $id, $existingQualificationName, false);
                } catch (Throwable $syncError) {
                    error_log('Qualification room sync delete failed: ' . $syncError->getMessage());
                }

                echo json_encode([
                    'success' => true,
                    'message' => 'Yeterlilik başarıyla silindi!',
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Silme işlemi başarısız!',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        default:
            echo json_encode([
                'success' => false,
                'message' => 'Geçersiz işlem! Action: ' . $action,
            ], JSON_UNESCAPED_UNICODE);
            break;
    }
} catch (Throwable $e) {
    echo json_encode([
        'success' => false,
        'message' => 'İşlem sırasında bir sunucu hatası oluştu.',
    ], JSON_UNESCAPED_UNICODE);
}

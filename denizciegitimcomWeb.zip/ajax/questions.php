<?php
header('Content-Type: application/json; charset=utf-8');

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/question_scope_helper.php';
require_once '../includes/upload_helper.php';

$user = require_admin();
$action = $_GET['action'] ?? $_POST['action'] ?? '';

function normalize_question_source_type($value): string
{
    $sourceType = strtolower(trim((string)$value));
    return in_array($sourceType, ['scenario', 'gasm'], true) ? $sourceType : 'scenario';
}

function normalize_question_badge_type($value): string
{
    $badgeType = strtolower(trim((string)$value));
    return in_array($badgeType, ['normal', 'new'], true) ? $badgeType : 'normal';
}

function questions_json($success, $message = '', $data = [], $status = 200)
{
    http_response_code($status);
    echo json_encode([
        'success' => (bool)$success,
        'message' => $message,
        'data' => $data,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

function question_optional_image_file_present(array $file): bool
{
    return isset($file['error']) && (int)$file['error'] !== UPLOAD_ERR_NO_FILE && trim((string)($file['tmp_name'] ?? '')) !== '';
}

function store_question_optional_image(array $file, string $kind): array
{
    if (!question_optional_image_file_present($file)) {
        return [];
    }

    if (!in_array($kind, ['question', 'explanation'], true)) {
        throw new InvalidArgumentException('Geçersiz görsel türü.');
    }

    $subDir = 'images/' . date('Y') . '/' . date('m');
    $saved = upload_store_image_fit_variants('questions', $subDir, $file, $kind . '-image', [
        'large' => ['max_width' => 1200, 'max_height' => 1600, 'quality' => 82],
        'thumb' => ['max_width' => 360, 'max_height' => 360, 'quality' => 74],
    ]);

    $prefix = $kind === 'question' ? 'question_image' : 'explanation_image';
    return [
        $prefix . '_large_url' => $saved['large']['public_url'] ?? null,
        $prefix . '_large_path' => $saved['large']['relative_path'] ?? null,
        $prefix . '_thumb_url' => $saved['thumb']['public_url'] ?? null,
        $prefix . '_thumb_path' => $saved['thumb']['relative_path'] ?? null,
    ];
}

function normalize_question_image_urls(array &$row): void
{
    foreach (['question_image_large', 'question_image_thumb', 'explanation_image_large', 'explanation_image_thumb'] as $base) {
        $urlKey = $base . '_url';
        $pathKey = $base . '_path';
        if (empty($row[$urlKey]) && !empty($row[$pathKey])) {
            $row[$urlKey] = upload_build_public_url((string)$row[$pathKey]);
        }
    }
}

function delete_question_image_kind_files(array $row, string $kind): void
{
    $prefix = $kind === 'question' ? 'question_image' : 'explanation_image';
    foreach ([$prefix . '_large_path', $prefix . '_large_url', $prefix . '_thumb_path', $prefix . '_thumb_url'] as $key) {
        if (!empty($row[$key])) {
            upload_safe_delete((string)$row[$key], 'questions');
        }
    }
}

function delete_question_image_files(array $row): void
{
    delete_question_image_kind_files($row, 'question');
    delete_question_image_kind_files($row, 'explanation');
}

try {
    $questionCols = get_table_columns($pdo, 'questions');
    $hasOptionE = is_array($questionCols) && in_array('option_e', $questionCols, true);
    $hasTopicId = is_array($questionCols) && in_array('topic_id', $questionCols, true);
    $hasStatus = is_array($questionCols) && in_array('status', $questionCols, true);
    $hasIsActive = is_array($questionCols) && in_array('is_active', $questionCols, true);
    $hasQuestionBadgeType = is_array($questionCols) && in_array('question_badge_type', $questionCols, true);

    switch ($action) {
        case 'list_qualifications':
            $rows = $pdo->query('SELECT id, name FROM qualifications ORDER BY order_index ASC, name ASC')->fetchAll(PDO::FETCH_ASSOC);
            questions_json(true, '', ['qualifications' => $rows]);
            break;

        case 'list_courses':
            $qualificationId = trim((string)($_GET['qualification_id'] ?? ''));
            $sql = 'SELECT c.id, c.name, c.qualification_id, q.name AS qualification_name
                    FROM courses c
                    LEFT JOIN qualifications q ON q.id = c.qualification_id';
            $params = [];
            if ($qualificationId !== '') {
                $sql .= ' WHERE c.qualification_id = ?';
                $params[] = $qualificationId;
            }
            $sql .= ' ORDER BY q.order_index ASC, c.order_index ASC, c.name ASC';
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            questions_json(true, '', ['courses' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            break;

        case 'list_topics':
            if (!$hasTopicId) {
                questions_json(true, '', ['topics' => [], 'meta' => ['has_topic_filter' => false]]);
            }

            $courseId = trim((string)($_GET['course_id'] ?? ''));
            $sql = 'SELECT t.id, t.course_id, t.name
                    FROM topics t';
            $params = [];
            if ($courseId !== '') {
                $sql .= ' WHERE t.course_id = ?';
                $params[] = $courseId;
            }
            $sql .= ' ORDER BY COALESCE(t.order_index, 0) ASC, t.name ASC';
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            questions_json(true, '', ['topics' => $stmt->fetchAll(PDO::FETCH_ASSOC), 'meta' => ['has_topic_filter' => true]]);
            break;

        case 'list_questions':
            $qualificationId = trim((string)($_GET['qualification_id'] ?? ''));
            $courseId = trim((string)($_GET['course_id'] ?? ''));
            $topicId = trim((string)($_GET['topic_id'] ?? ''));
            $questionType = trim((string)($_GET['question_type'] ?? ''));
            $sourceTypeFilter = strtolower(trim((string)($_GET['source_type'] ?? 'all')));
            if (!in_array($sourceTypeFilter, ['', 'all', 'scenario', 'gasm'], true)) {
                $sourceTypeFilter = 'all';
            }
            $statusFilter = trim((string)($_GET['status'] ?? ''));
            $search = trim((string)($_GET['search'] ?? ''));
            $search = preg_replace('/\s+/u', ' ', $search);
            $searchScope = (string)($_GET['search_scope'] ?? 'all');
            $searchScope = in_array($searchScope, ['all', 'visible'], true) ? $searchScope : 'all';
            $page = max(1, (int)($_GET['page'] ?? 1));
            $allowedPerPage = [25, 50, 100, 500];
            $perPage = (int)($_GET['per_page'] ?? 25);
            if (!in_array($perPage, $allowedPerPage, true)) {
                $perPage = 25;
            }
            $offset = ($page - 1) * $perPage;

            $select = 'q.*, c.name AS course_name, qual.name AS qualification_name';
            $join = ' FROM questions q
                      LEFT JOIN courses c ON q.course_id = c.id
                      LEFT JOIN qualifications qual ON c.qualification_id = qual.id';
            if ($hasTopicId) {
                $select .= ', t.name AS topic_name';
                $join .= ' LEFT JOIN topics t ON q.topic_id = t.id';
            } else {
                $select .= ', NULL AS topic_name';
            }

            $where = ['1=1'];
            $params = [];

            if ($qualificationId !== '') {
                $where[] = 'c.qualification_id = ?';
                $params[] = $qualificationId;
            }
            if ($courseId !== '') {
                $where[] = 'q.course_id = ?';
                $params[] = $courseId;
            }
            if ($hasTopicId && $topicId !== '') {
                $where[] = 'q.topic_id = ?';
                $params[] = $topicId;
            }
            if ($questionType !== '') {
                $where[] = 'q.question_type = ?';
                $params[] = $questionType;
            }
            if ($sourceTypeFilter === 'scenario') {
                $where[] = 'q.source_type = ?';
                $params[] = 'scenario';
            } elseif ($sourceTypeFilter === 'gasm') {
                $where[] = 'q.source_type = ?';
                $params[] = 'gasm';
            }

            if ($hasStatus && $statusFilter !== '') {
                $where[] = 'q.status = ?';
                $params[] = $statusFilter;
            } elseif ($hasIsActive && $statusFilter !== '') {
                if ($statusFilter === 'active') {
                    $where[] = 'q.is_active = 1';
                } elseif ($statusFilter === 'inactive') {
                    $where[] = 'q.is_active = 0';
                }
            }

            $like = '';
            if ($search !== '') {
                $needle = mb_strtolower($search, 'UTF-8');
                $like = '%' . $needle . '%';

                $normExpr = "LOWER(REPLACE(REPLACE(REPLACE(COALESCE(%s, ''), '\\r', ' '), '\\n', ' '), '\\t', ' '))";

                $searchColumns = [
                    'q.question_text',
                    'q.option_a',
                    'q.option_b',
                    'q.option_c',
                    'q.option_d',
                ];
                if ($hasOptionE) {
                    $searchColumns[] = 'q.option_e';
                }
                if ($searchScope === 'all') {
                    $searchColumns[] = 'q.explanation';
                }

                $searchWhere = array_map(static function ($col) use ($normExpr) {
                    return sprintf($normExpr, $col) . ' LIKE ?';
                }, $searchColumns);

                $where[] = '(' . implode(' OR ', $searchWhere) . ')';

                foreach ($searchColumns as $_unused) {
                    $params[] = $like;
                }
            }

            $countSql = 'SELECT COUNT(*)' . $join . ' WHERE ' . implode(' AND ', $where);
            $countStmt = $pdo->prepare($countSql);
            $countStmt->execute($params);
            $totalCount = (int)$countStmt->fetchColumn();

            $sql = 'SELECT ' . $select . $join . ' WHERE ' . implode(' AND ', $where) . ' ORDER BY q.created_at DESC, q.id DESC LIMIT ? OFFSET ?';
            $stmt = $pdo->prepare($sql);
            $queryParams = $params;
            $queryParams[] = $perPage;
            $queryParams[] = $offset;
            foreach ($queryParams as $idx => $value) {
                $paramType = is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR;
                $stmt->bindValue($idx + 1, $value, $paramType);
            }
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($search !== '') {
                $rows = array_values(array_filter($rows, static function ($row) use ($search, $hasOptionE, $searchScope) {
                    $matchedFields = [];
                    $fieldsToCheck = [
                        'question_text' => (string)($row['question_text'] ?? ''),
                        'option_a' => (string)($row['option_a'] ?? ''),
                        'option_b' => (string)($row['option_b'] ?? ''),
                        'option_c' => (string)($row['option_c'] ?? ''),
                        'option_d' => (string)($row['option_d'] ?? ''),
                    ];
                    if ($hasOptionE) {
                        $fieldsToCheck['option_e'] = (string)($row['option_e'] ?? '');
                    }
                    if ($searchScope === 'all') {
                        $fieldsToCheck['explanation'] = (string)($row['explanation'] ?? '');
                    }

                    $normalizedNeedle = mb_strtolower(preg_replace('/\s+/u', ' ', trim($search)), 'UTF-8');

                    foreach ($fieldsToCheck as $fieldName => $value) {
                        $normalizedHaystack = mb_strtolower(
                            preg_replace('/\s+/u', ' ', str_replace(["\r", "\n", "\t"], ' ', $value)),
                            'UTF-8'
                        );

                        if ($normalizedNeedle !== '' && mb_stripos($normalizedHaystack, $normalizedNeedle, 0, 'UTF-8') !== false) {
                            $matchedFields[] = $fieldName;
                        }
                    }

                    $row['matched_fields'] = $matchedFields;

                    return !empty($matchedFields);
                }));

                foreach ($rows as &$row) {
                    $matchedFields = [];
                    $fieldsToCheck = [
                        'question_text' => (string)($row['question_text'] ?? ''),
                        'option_a' => (string)($row['option_a'] ?? ''),
                        'option_b' => (string)($row['option_b'] ?? ''),
                        'option_c' => (string)($row['option_c'] ?? ''),
                        'option_d' => (string)($row['option_d'] ?? ''),
                    ];
                    if ($hasOptionE) {
                        $fieldsToCheck['option_e'] = (string)($row['option_e'] ?? '');
                    }
                    if ($searchScope === 'all') {
                        $fieldsToCheck['explanation'] = (string)($row['explanation'] ?? '');
                    }

                    $normalizedNeedle = mb_strtolower($search, 'UTF-8');
                    foreach ($fieldsToCheck as $fieldName => $value) {
                        $normalizedHaystack = mb_strtolower(
                            preg_replace('/\s+/u', ' ', str_replace(["\r", "\n", "\t"], ' ', $value)),
                            'UTF-8'
                        );
                        if ($normalizedNeedle !== '' && mb_stripos($normalizedHaystack, $normalizedNeedle, 0, 'UTF-8') !== false) {
                            $matchedFields[] = $fieldName;
                        }
                    }
                    $row['matched_fields'] = $matchedFields;
                }
                unset($row);

            }

            foreach ($rows as &$row) {
                normalize_question_image_urls($row);
                $row['formatted_explanation'] = format_explanation_text($row['explanation'] ?? '');
            }
            unset($row);

            $statusOptions = [];
            if ($hasStatus) {
                $statusRows = $pdo->query('SELECT DISTINCT status FROM questions WHERE status IS NOT NULL AND status <> "" ORDER BY status ASC')->fetchAll(PDO::FETCH_COLUMN);
                foreach ($statusRows as $s) {
                    $statusOptions[] = ['value' => (string)$s, 'label' => (string)$s];
                }
            } elseif ($hasIsActive) {
                $statusOptions[] = ['value' => 'active', 'label' => 'Aktif'];
                $statusOptions[] = ['value' => 'inactive', 'label' => 'Pasif'];
            }

            questions_json(true, '', [
                'questions' => $rows,
                'total_count' => $totalCount,
                'pagination' => [
                    'page' => $page,
                    'per_page' => $perPage,
                    'total_count' => $totalCount,
                    'total_pages' => max(1, (int)ceil($totalCount / $perPage)),
                ],
                'meta' => [
                    'has_topic_filter' => $hasTopicId,
                    'has_status_filter' => ($hasStatus || $hasIsActive),
                    'status_options' => $statusOptions,
                    'search_debug' => [
                        'raw' => $_GET['search'] ?? '',
                        'normalized' => $search,
                        'mode' => 'exact_phrase',
                        'like' => $like,
                        'search_scope' => $searchScope,
                    ],
                    'search_scope' => $searchScope,
                ],
            ]);
            break;

        case 'add':
            $course_id = $_POST['course_id'] ?? '';
            $topic_id = normalize_optional_uuid($_POST['topic_id'] ?? null);
            $question_type = $_POST['question_type'] ?? '';
            $source_type = normalize_question_source_type($_POST['source_type'] ?? 'scenario');
            $question_badge_type = normalize_question_badge_type($_POST['question_badge_type'] ?? 'normal');
            $question_text = sanitize_input($_POST['question_text'] ?? '');
            $option_a = sanitize_input($_POST['option_a'] ?? '');
            $option_b = sanitize_input($_POST['option_b'] ?? '');
            $option_c = sanitize_input($_POST['option_c'] ?? '');
            $option_d = sanitize_input($_POST['option_d'] ?? '');
            $option_e = sanitize_input($_POST['option_e'] ?? '');
            $correct_answer = strtoupper(trim((string)($_POST['correct_answer'] ?? '')));
            $explanation = sanitize_input($_POST['explanation'] ?? '');

            if (empty($course_id) || empty($question_type) || empty($question_text) ||
                empty($option_a) || empty($option_b) || empty($option_c) ||
                empty($option_d) || empty($correct_answer)) {
                questions_json(false, 'Tüm zorunlu alanları doldurun!', [], 422);
            }

            if ($hasTopicId && !validate_topic_belongs_to_course($pdo, $topic_id, $course_id)) {
                questions_json(false, 'Seçilen konu bu derse ait değil!', [], 422);
            }

            if (!in_array($question_type, ['sayısal', 'sözel', 'karışık'], true)) {
                questions_json(false, 'Geçersiz soru tipi!', [], 422);
            }

            if (!in_array($correct_answer, ['A', 'B', 'C', 'D', 'E'], true)) {
                questions_json(false, 'Geçersiz doğru cevap!', [], 422);
            }

            if ($correct_answer === 'E' && $option_e === '') {
                questions_json(false, 'E doğru cevap için Şık E doldurulmalıdır!', [], 422);
            }

            if (!$hasOptionE && $correct_answer === 'E') {
                questions_json(false, 'correct_answer E seçildi ancak option_e kolonu bulunamadı.', ['error_code' => 'correct_answer_e_but_option_e_not_supported'], 422);
            }

            $id = generate_uuid();
            $questionImageData = store_question_optional_image($_FILES['question_image'] ?? [], 'question');
            $explanationImageData = store_question_optional_image($_FILES['explanation_image'] ?? [], 'explanation');
            $imageData = array_merge($questionImageData, $explanationImageData);

            $pdo->beginTransaction();
            try {
                $insertData = [
                    'id' => $id,
                    'course_id' => $course_id,
                    'question_type' => $question_type,
                    'source_type' => $source_type,
                    'question_text' => $question_text,
                    'option_a' => $option_a,
                    'option_b' => $option_b,
                    'option_c' => $option_c,
                    'option_d' => $option_d,
                    'correct_answer' => $correct_answer,
                    'explanation' => $explanation,
                ];
                if ($hasTopicId) {
                    $insertData['topic_id'] = $topic_id;
                }
                if ($hasOptionE) {
                    $insertData['option_e'] = ($option_e !== '' ? $option_e : null);
                }
                if ($hasQuestionBadgeType) {
                    $insertData['question_badge_type'] = $question_badge_type;
                }
                $insertData = array_merge($insertData, $imageData);

                $cols = array_keys($insertData);
                $placeholders = array_fill(0, count($cols), '?');
                $cols[] = 'created_at';
                $placeholders[] = 'NOW()';
                $stmt = $pdo->prepare('INSERT INTO questions (' . implode(', ', $cols) . ') VALUES (' . implode(', ', $placeholders) . ')');
                $ok = $stmt->execute(array_values($insertData));

                if (!$ok) {
                    throw new RuntimeException('Veritabanı hatası!');
                }

                if (question_scope_has_links_table($pdo)) {
                    question_scope_replace_primary_from_question($pdo, $id);
                }

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                delete_question_image_files($imageData);
                throw $e;
            }

            if (!empty($ok)) {
                questions_json(true, 'Soru başarıyla eklendi!', ['id' => $id]);
            } else {
                questions_json(false, 'Veritabanı hatası!', [], 500);
            }
            break;

        case 'get':
            $id = $_GET['id'] ?? '';

            if (empty($id)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'ID gerekli!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $stmt = $pdo->prepare('SELECT * FROM questions WHERE id = ?');
            $stmt->execute([$id]);
            $data = $stmt->fetch();

            if ($data) {
                normalize_question_image_urls($data);
                echo json_encode([
                    'success' => true,
                    'data' => $data,
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Soru bulunamadı!',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'scope_list':
            $questionId = trim((string)($_GET['id'] ?? $_GET['question_id'] ?? ''));
            if ($questionId === '') {
                questions_json(false, 'question_id gerekli!', [], 422);
            }

            if (!question_scope_has_links_table($pdo)) {
                questions_json(true, '', ['scopes' => [], 'meta' => ['has_scope_links_table' => false]]);
            }

            $scopes = question_scope_list_for_question($pdo, $questionId);
            questions_json(true, '', ['scopes' => $scopes, 'meta' => ['has_scope_links_table' => true]]);
            break;

        case 'scope_add':
            $questionId = trim((string)($_POST['question_id'] ?? ''));
            $qualificationId = trim((string)($_POST['qualification_id'] ?? ''));
            $courseId = trim((string)($_POST['course_id'] ?? ''));
            $topicId = question_scope_normalize_topic_id($_POST['topic_id'] ?? '');

            if ($questionId === '' || $qualificationId === '' || $courseId === '') {
                questions_json(false, 'question_id, qualification_id ve course_id zorunludur.', [], 422);
            }

            if (!question_scope_has_links_table($pdo)) {
                questions_json(false, 'question_scope_links tablosu bulunamadı.', [], 422);
            }

            $scope = question_scope_add($pdo, $questionId, $qualificationId, $courseId, $topicId, 0);
            questions_json(true, 'Kapsam eklendi.', ['scope' => $scope]);
            break;

        case 'scope_delete':
            $scopeId = trim((string)($_POST['scope_id'] ?? ''));
            if ($scopeId === '') {
                questions_json(false, 'scope_id zorunludur.', [], 422);
            }

            if (!question_scope_has_links_table($pdo)) {
                questions_json(false, 'question_scope_links tablosu bulunamadı.', [], 422);
            }

            question_scope_delete($pdo, $scopeId);
            questions_json(true, 'Kapsam silindi.');
            break;

        case 'update':
            $id = $_POST['id'] ?? '';
            $course_id = $_POST['course_id'] ?? '';
            $topic_id = normalize_optional_uuid($_POST['topic_id'] ?? null);
            $question_type = $_POST['question_type'] ?? '';
            $source_type = array_key_exists('source_type', $_POST)
                ? normalize_question_source_type($_POST['source_type'])
                : null;
            $question_badge_type = normalize_question_badge_type($_POST['question_badge_type'] ?? 'normal');
            $question_text = sanitize_input($_POST['question_text'] ?? '');
            $option_a = sanitize_input($_POST['option_a'] ?? '');
            $option_b = sanitize_input($_POST['option_b'] ?? '');
            $option_c = sanitize_input($_POST['option_c'] ?? '');
            $option_d = sanitize_input($_POST['option_d'] ?? '');
            $option_e = sanitize_input($_POST['option_e'] ?? '');
            $correct_answer = strtoupper(trim((string)($_POST['correct_answer'] ?? '')));
            $explanation = sanitize_input($_POST['explanation'] ?? '');

            if (empty($id)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'ID gerekli!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if (empty($course_id) || empty($question_type) || empty($question_text) ||
                empty($option_a) || empty($option_b) || empty($option_c) ||
                empty($option_d) || empty($correct_answer)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Tüm zorunlu alanları doldurun!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if ($hasTopicId && !validate_topic_belongs_to_course($pdo, $topic_id, $course_id)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Seçilen konu bu derse ait değil!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if (!in_array($question_type, ['sayısal', 'sözel', 'karışık'], true)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Geçersiz soru tipi!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if (!in_array($correct_answer, ['A', 'B', 'C', 'D', 'E'], true)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Geçersiz doğru cevap!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if ($correct_answer === 'E' && $option_e === '') {
                echo json_encode([
                    'success' => false,
                    'message' => 'E doğru cevap için Şık E doldurulmalıdır!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if (!$hasOptionE && $correct_answer === 'E') {
                echo json_encode([
                    'success' => false,
                    'message' => 'correct_answer E seçildi ancak option_e kolonu bulunamadı.',
                    'error_code' => 'correct_answer_e_but_option_e_not_supported',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $pdo->beginTransaction();
            try {
                $stmtExisting = $pdo->prepare('SELECT * FROM questions WHERE id = ? LIMIT 1');
                $stmtExisting->execute([$id]);
                $existingQuestion = $stmtExisting->fetch(PDO::FETCH_ASSOC);
                if (!$existingQuestion) {
                    throw new RuntimeException('Soru bulunamadı!');
                }

                if ($source_type === null) {
                    $source_type = normalize_question_source_type($existingQuestion['source_type'] ?? 'scenario');
                }

                $updateData = [
                    'course_id' => $course_id,
                    'question_type' => $question_type,
                    'source_type' => $source_type,
                    'question_text' => $question_text,
                    'option_a' => $option_a,
                    'option_b' => $option_b,
                    'option_c' => $option_c,
                    'option_d' => $option_d,
                    'correct_answer' => $correct_answer,
                    'explanation' => $explanation,
                ];
                if ($hasTopicId) {
                    $updateData['topic_id'] = $topic_id;
                }
                if ($hasOptionE) {
                    $updateData['option_e'] = ($option_e !== '' ? $option_e : null);
                }
                if ($hasQuestionBadgeType) {
                    $updateData['question_badge_type'] = $question_badge_type;
                }

                $newImageData = [];
                foreach (['question', 'explanation'] as $kind) {
                    $fileKey = $kind . '_image';
                    $removeKey = 'remove_' . $kind . '_image';
                    $remove = !empty($_POST[$removeKey]) && (string)$_POST[$removeKey] !== '0';
                    $hasNewFile = question_optional_image_file_present($_FILES[$fileKey] ?? []);
                    $prefix = $kind === 'question' ? 'question_image' : 'explanation_image';

                    if ($remove || $hasNewFile) {
                        delete_question_image_kind_files($existingQuestion, $kind);
                        $updateData[$prefix . '_large_url'] = null;
                        $updateData[$prefix . '_large_path'] = null;
                        $updateData[$prefix . '_thumb_url'] = null;
                        $updateData[$prefix . '_thumb_path'] = null;
                    }

                    if ($hasNewFile) {
                        $stored = store_question_optional_image($_FILES[$fileKey], $kind);
                        $newImageData = array_merge($newImageData, $stored);
                        $updateData = array_merge($updateData, $stored);
                    }
                }

                $sets = [];
                $params = [];
                foreach ($updateData as $col => $value) {
                    $sets[] = $col . ' = ?';
                    $params[] = $value;
                }
                $params[] = $id;
                $stmt = $pdo->prepare('UPDATE questions SET ' . implode(', ', $sets) . ' WHERE id = ?');
                $ok = $stmt->execute($params);

                if (!empty($ok) && question_scope_has_links_table($pdo)) {
                    question_scope_replace_primary_from_question($pdo, $id);
                }

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                if (!empty($newImageData)) {
                    delete_question_image_files($newImageData);
                }
                throw $e;
            }

            if ($ok) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Soru güncellendi!',
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Güncelleme başarısız!',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'update_source_type':
            $id = trim((string)($_POST['id'] ?? ''));
            $sourceTypeRaw = $_POST['source_type'] ?? '';
            if ($id === '') {
                questions_json(false, 'ID gerekli!', [], 422);
            }

            $sourceType = strtolower(trim((string)$sourceTypeRaw));
            if (!in_array($sourceType, ['scenario', 'gasm'], true)) {
                questions_json(false, 'Geçersiz source_type!', [], 422);
            }

            $stmt = $pdo->prepare('UPDATE questions SET source_type = ?, updated_at = NOW() WHERE id = ?');
            $ok = $stmt->execute([$sourceType, $id]);
            if (!$ok) {
                questions_json(false, 'Güncelleme başarısız!', [], 500);
            }
            questions_json(true, 'Soru kaynak tipi güncellendi.');
            break;

        case 'update_badge_type':
            $id = trim((string)($_POST['id'] ?? ''));
            $badgeTypeRaw = $_POST['question_badge_type'] ?? '';
            if ($id === '') {
                questions_json(false, 'ID gerekli!', [], 422);
            }

            $badgeType = strtolower(trim((string)$badgeTypeRaw));
            if (!in_array($badgeType, ['normal', 'new'], true)) {
                questions_json(false, 'Geçersiz question_badge_type!', [], 422);
            }

            if (!$hasQuestionBadgeType) {
                questions_json(false, 'question_badge_type kolonu bulunamadı.', [], 422);
            }

            $stmt = $pdo->prepare('UPDATE questions SET question_badge_type = ?, updated_at = NOW() WHERE id = ?');
            $ok = $stmt->execute([$badgeType, $id]);
            if (!$ok) {
                questions_json(false, 'Güncelleme başarısız!', [], 500);
            }
            questions_json(true, 'Soru etiket durumu güncellendi.');
            break;

        case 'delete':
            $id = $_POST['id'] ?? '';

            if (empty($id)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'ID gerekli!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $pdo->beginTransaction();
            try {
                $stmtExisting = $pdo->prepare('SELECT * FROM questions WHERE id = ? LIMIT 1');
                $stmtExisting->execute([$id]);
                $existingQuestion = $stmtExisting->fetch(PDO::FETCH_ASSOC) ?: [];

                if (question_scope_has_links_table($pdo)) {
                    $pdo->prepare('DELETE FROM question_scope_links WHERE question_id = ?')->execute([$id]);
                }

                $stmt = $pdo->prepare('DELETE FROM questions WHERE id = ?');
                $ok = $stmt->execute([$id]);
                if (!$ok) {
                    throw new RuntimeException('Silme başarısız!');
                }

                $pdo->commit();
                delete_question_image_files($existingQuestion);
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                throw $e;
            }

            if (!empty($ok)) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Soru silindi!',
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Silme başarısız!',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'bulk_delete':
            $ids = $_POST['ids'] ?? [];

            if (empty($ids) || !is_array($ids)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Silinecek soru seçilmedi!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $valid_ids = array_values(array_filter($ids, static function ($id) {
                return !empty($id) && strlen((string)$id) === 36;
            }));

            if (empty($valid_ids)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Geçersiz ID listesi!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $placeholders = implode(',', array_fill(0, count($valid_ids), '?'));

            $pdo->beginTransaction();
            try {
                $stmtRows = $pdo->prepare("SELECT * FROM questions WHERE id IN ($placeholders)");
                $stmtRows->execute($valid_ids);
                $rowsToDelete = $stmtRows->fetchAll(PDO::FETCH_ASSOC) ?: [];

                if (question_scope_has_links_table($pdo)) {
                    $stmtScope = $pdo->prepare("DELETE FROM question_scope_links WHERE question_id IN ($placeholders)");
                    $stmtScope->execute($valid_ids);
                }

                $stmt = $pdo->prepare("DELETE FROM questions WHERE id IN ($placeholders)");
                $ok = $stmt->execute($valid_ids);
                if (!$ok) {
                    throw new RuntimeException('Silme işlemi başarısız!');
                }

                $deleted = $stmt->rowCount();
                $pdo->commit();

                foreach ($rowsToDelete as $rowToDelete) {
                    delete_question_image_files($rowToDelete);
                }
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                throw $e;
            }

            if (!empty($ok)) {
                echo json_encode([
                    'success' => true,
                    'message' => $deleted . ' soru başarıyla silindi!',
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Silme işlemi başarısız!',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'save_generated':
            $questions_json = $_POST['questions'] ?? '';
            $bulkBadgeType = normalize_question_badge_type($_POST['question_badge_type'] ?? 'normal');
            if ($questions_json === '') {
                questions_json(false, 'Soru verisi gönderilmedi!', [], 422);
            }

            $questions = json_decode($questions_json, true);
            if (!is_array($questions) || empty($questions)) {
                questions_json(false, 'Geçersiz soru verisi!', [], 422);
            }

            $typeMap = [
                'mixed' => 'karışık',
                'verbal' => 'sözel',
                'numerical' => 'sayısal',
                'karışık' => 'karışık',
                'sözel' => 'sözel',
                'sayısal' => 'sayısal',
            ];

            $savedCount = 0;
            $skippedCount = 0;
            $skippedReasons = [];

            foreach ($questions as $q) {
                if (($q['status'] ?? 'pending') !== 'approved') {
                    $skippedCount++;
                    $skippedReasons['status_not_approved'] = (int)($skippedReasons['status_not_approved'] ?? 0) + 1;
                    continue;
                }

                $questionText = sanitize_input($q['question_text'] ?? '');
                $optionA = sanitize_input($q['option_a'] ?? '');
                $optionB = sanitize_input($q['option_b'] ?? '');
                $optionC = sanitize_input($q['option_c'] ?? '');
                $optionD = sanitize_input($q['option_d'] ?? '');
                $optionE = sanitize_input($q['option_e'] ?? '');
                $correctAnswer = strtoupper(trim((string)($q['correct_answer'] ?? '')));
                $courseId = trim((string)($q['course_id'] ?? ''));
                $questionTypeRaw = trim((string)($q['question_type'] ?? ''));
                $normalizedType = $typeMap[$questionTypeRaw] ?? null;
                $topicId = normalize_optional_uuid($q['topic_id'] ?? null);
                $sourceType = normalize_question_source_type($q['source_type'] ?? 'scenario');
                $explanation = sanitize_input($q['explanation'] ?? '');

                $isValid = $questionText !== ''
                    && $optionA !== '' && $optionB !== '' && $optionC !== '' && $optionD !== ''
                    && $courseId !== '' && $normalizedType !== null
                    && in_array($correctAnswer, ['A', 'B', 'C', 'D', 'E'], true);

                if (!$isValid) {
                    $skippedCount++;
                    $skippedReasons['invalid_or_missing_fields'] = (int)($skippedReasons['invalid_or_missing_fields'] ?? 0) + 1;
                    continue;
                }

                if ($correctAnswer === 'E' && $optionE === '') {
                    $skippedCount++;
                    $skippedReasons['correct_answer_e_without_option_e'] = (int)($skippedReasons['correct_answer_e_without_option_e'] ?? 0) + 1;
                    continue;
                }

                if (!$hasOptionE && $correctAnswer === 'E') {
                    $skippedCount++;
                    $skippedReasons['db_has_no_option_e_for_e_answer'] = (int)($skippedReasons['db_has_no_option_e_for_e_answer'] ?? 0) + 1;
                    continue;
                }

                if ($hasTopicId && !validate_topic_belongs_to_course($pdo, $topicId, $courseId)) {
                    $skippedCount++;
                    $skippedReasons['topic_not_belongs_to_course'] = (int)($skippedReasons['topic_not_belongs_to_course'] ?? 0) + 1;
                    continue;
                }

                $id = generate_uuid();
                $insertData = [
                    'id' => $id,
                    'course_id' => $courseId,
                    'question_type' => $normalizedType,
                    'source_type' => $sourceType,
                    'question_text' => $questionText,
                    'option_a' => $optionA,
                    'option_b' => $optionB,
                    'option_c' => $optionC,
                    'option_d' => $optionD,
                    'correct_answer' => $correctAnswer,
                    'explanation' => $explanation,
                ];
                if ($hasTopicId) {
                    $insertData['topic_id'] = $topicId;
                }
                if ($hasOptionE) {
                    $insertData['option_e'] = ($optionE !== '' ? $optionE : null);
                }
                if ($hasQuestionBadgeType) {
                    $insertData['question_badge_type'] = $bulkBadgeType;
                }

                $cols = array_keys($insertData);
                $placeholders = array_fill(0, count($cols), '?');
                $cols[] = 'created_at';
                $placeholders[] = 'NOW()';
                $stmt = $pdo->prepare('INSERT INTO questions (' . implode(', ', $cols) . ') VALUES (' . implode(', ', $placeholders) . ')');
                $ok = $stmt->execute(array_values($insertData));

                if (!$ok) {
                    $skippedCount++;
                    $skippedReasons['db_insert_failed'] = (int)($skippedReasons['db_insert_failed'] ?? 0) + 1;
                    continue;
                }

                if (question_scope_has_links_table($pdo)) {
                    question_scope_replace_primary_from_question($pdo, $id);
                }

                $savedCount++;
            }

            if ($savedCount > 0) {
                questions_json(true, $savedCount . ' soru başarıyla kaydedildi!', [
                    'saved_count' => $savedCount,
                    'skipped_count' => $skippedCount,
                    'skipped_reasons' => $skippedReasons,
                ]);
            }

            questions_json(false, 'Hiçbir onaylı soru kaydedilemedi!', [
                'saved_count' => 0,
                'skipped_count' => $skippedCount,
                'skipped_reasons' => $skippedReasons,
            ], 422);
            break;

        default:
            echo json_encode([
                'success' => false,
                'message' => 'Geçersiz işlem!',
            ], JSON_UNESCAPED_UNICODE);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'İşlem sırasında bir sunucu hatası oluştu.',
    ], JSON_UNESCAPED_UNICODE);
}

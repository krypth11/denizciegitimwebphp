<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

$user = require_admin();
$current_page = 'question-scope-bulk';
$page_title = 'Toplu Soru Kapsamı';

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="container-fluid">
    <div class="page-header">
        <div>
            <h2>Toplu Soru Kapsamı</h2>
            <p class="text-muted mb-0">Kaynak filtreye uyan sorular için hedef kapsama toplu ekleme / kaldırma yapın.</p>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-7">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <h5 class="mb-3">A) Kaynak Soru Filtresi</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Kaynak yeterlilik *</label>
                            <select class="form-select" id="sourceQualification">
                                <option value="">Seçiniz...</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Kaynak ders *</label>
                            <select class="form-select" id="sourceCourse" disabled>
                                <option value="">Önce yeterlilik seçin...</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Kaynak konu <span class="text-muted">(opsiyonel)</span></label>
                            <select class="form-select" id="sourceTopic" disabled>
                                <option value="">Tüm konular</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Soru tipi <span class="text-muted">(opsiyonel)</span></label>
                            <select class="form-select" id="questionType">
                                <option value="">Tümü</option>
                                <option value="sayısal">Sayısal</option>
                                <option value="sözel">Sözel</option>
                                <option value="karışık">Karışık</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Arama <span class="text-muted">(opsiyonel)</span></label>
                            <input type="search" class="form-control" id="searchText" placeholder="question_text içinde ara...">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <h5 class="mb-3">B) Hedef Kapsam</h5>
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label">Hedef yeterlilik *</label>
                            <select class="form-select" id="targetQualification">
                                <option value="">Seçiniz...</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Hedef ders *</label>
                            <select class="form-select" id="targetCourse" disabled>
                                <option value="">Önce yeterlilik seçin...</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Hedef konu <span class="text-muted">(opsiyonel)</span></label>
                            <select class="form-select" id="targetTopic" disabled>
                                <option value="">Konu seçmeden devam et</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm mt-3">
        <div class="card-body">
            <div class="d-flex flex-wrap gap-2 mb-3">
                <button class="btn btn-outline-primary" id="previewBtn">
                    <i class="bi bi-search"></i> Önizleme / Sayı Getir
                </button>
                <button class="btn btn-success" id="bulkAddBtn">
                    <i class="bi bi-plus-circle"></i> Toplu Kapsam Ekle
                </button>
                <button class="btn btn-danger" id="bulkRemoveBtn">
                    <i class="bi bi-dash-circle"></i> Toplu Kapsam Kaldır
                </button>
            </div>

            <div id="previewBox" class="d-none">
                <div class="row g-3">
                    <div class="col-md-3">
                        <div class="border rounded-3 p-3 bg-light-subtle">
                            <div class="small text-muted">Toplam kaynak soru</div>
                            <div class="h5 mb-0" id="pvTotal">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="border rounded-3 p-3 bg-light-subtle">
                            <div class="small text-muted">Zaten bağlı</div>
                            <div class="h5 mb-0" id="pvAlready">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="border rounded-3 p-3 bg-light-subtle">
                            <div class="small text-muted">Eklenecek</div>
                            <div class="h5 mb-0" id="pvWillAdd">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="border rounded-3 p-3 bg-light-subtle">
                            <div class="small text-muted">Primary sayısı</div>
                            <div class="h5 mb-0" id="pvPrimary">0</div>
                        </div>
                    </div>
                </div>

                <div class="mt-3">
                    <h6 class="mb-2">Örnek Sorular (İlk 10)</h6>
                    <div class="table-responsive">
                        <table class="table table-sm align-middle" id="sampleTable">
                            <thead>
                                <tr>
                                    <th style="width: 120px;">ID</th>
                                    <th>Soru Metni</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td colspan="2" class="text-muted">Henüz önizleme alınmadı.</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm mt-3">
        <div class="card-body">
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                <h5 class="mb-0">Kayıtlı Kapsam Eşleştirmeleri</h5>
                <div class="d-flex flex-wrap gap-2">
                    <button class="btn btn-outline-primary" id="refreshMappingsBtn">
                        <i class="bi bi-arrow-clockwise"></i> Listeyi Yenile
                    </button>
                    <button class="btn btn-outline-success" id="syncAllMappingsBtn">
                        <i class="bi bi-arrow-repeat"></i> Tümünü Eşzamanla
                    </button>
                    <button class="btn btn-primary" id="bulkSyncMappingsBtn">
                        <i class="bi bi-arrow-repeat"></i> Seçilenleri Eşzamanla
                    </button>
                    <button class="btn btn-outline-danger" id="bulkCancelMappingsBtn">
                        <i class="bi bi-x-circle"></i> Seçilenleri İptal Et
                    </button>
                </div>
            </div>

            <div class="alert alert-info py-2 small mb-3">
                Liste sayıları son eşzamanlama kaydından gelir. Güncel kontrol için Eşzamanla işlemini kullanın.
            </div>

            <div class="small text-muted mb-3">
                <i class="bi bi-info-circle"></i> Tüm kayıtlı eşleştirmeler küçük partiler halinde güncellenir.
            </div>

            <div id="syncAllProgressBox" class="border rounded-3 bg-light-subtle p-3 mb-3 d-none">
                <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2">
                    <div>
                        <strong>Tümünü Eşzamanla</strong>
                        <div class="small text-muted" id="syncAllProgressText">İşlenen: 0 / 0 • Yeni eklenen: 0 • Hata: 0</div>
                    </div>
                    <button class="btn btn-sm btn-outline-secondary" id="syncAllStopBtn" type="button">
                        <i class="bi bi-stop-circle"></i> Durdur
                    </button>
                </div>
                <div class="progress" role="progressbar" aria-label="Tüm eşleştirmeleri eşzamanlama ilerlemesi" aria-valuemin="0" aria-valuemax="100">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" id="syncAllProgressBar" style="width: 0%">0%</div>
                </div>
            </div>

            <div class="border rounded-3 bg-light-subtle p-3 mb-3">
                <div class="row g-2 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label small mb-1">Kaynak yeterlilik</label>
                        <select class="form-select form-select-sm" id="mappingSourceQualificationFilter">
                            <option value="">Tüm kaynak yeterlilikler</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small mb-1">Hedef yeterlilik</label>
                        <select class="form-select form-select-sm" id="mappingTargetQualificationFilter">
                            <option value="">Tüm hedef yeterlilikler</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small mb-1">Durum</label>
                        <select class="form-select form-select-sm" id="mappingStatusFilter">
                            <option value="">Tüm durumlar</option>
                            <option value="unchecked">Henüz kontrol edilmedi</option>
                            <option value="source_empty">Kaynak boş</option>
                            <option value="missing">Son kontrolde eksik var</option>
                            <option value="current">Son kontrolde güncel</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small mb-1">Genel arama</label>
                        <div class="input-group input-group-sm">
                            <input type="search" class="form-control" id="mappingListSearch" placeholder="Kaynak/hedef yeterlilik, ders, konu, soru tipi veya mapping araması...">
                            <button class="btn btn-outline-primary" id="filterMappingsBtn" type="button">Filtrele</button>
                            <button class="btn btn-outline-secondary" id="clearMappingsFiltersBtn" type="button">Temizle</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-sm align-middle" id="mappingsTable">
                    <thead>
                        <tr>
                            <th style="width: 42px;">
                                <input class="form-check-input" type="checkbox" id="selectAllMappings">
                            </th>
                            <th>Kaynak</th>
                            <th>Hedef</th>
                            <th>Filtre</th>
                            <th class="text-end">Kaynak soru (son kontrol)</th>
                            <th class="text-end">Hedef bağlı (son kontrol)</th>
                            <th class="text-end">Eksik (son kontrol)</th>
                            <th>Son kontrol durumu</th>
                            <th>Son eşzamanlama</th>
                            <th style="min-width: 180px;">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="10" class="text-muted">Yükleniyor...</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mt-3" id="mappingsPagination">
                <div class="small text-muted" id="mappingsPaginationInfo">Sayfa 1 / 1 • Toplam 0 eşleştirme</div>
                <div class="btn-group btn-group-sm" role="group" aria-label="Eşleştirme sayfalama">
                    <button class="btn btn-outline-secondary" id="prevMappingsPageBtn" type="button" disabled>Önceki</button>
                    <button class="btn btn-outline-secondary" id="nextMappingsPageBtn" type="button" disabled>Sonraki</button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$extra_js = <<<'JS'
<script>
$(function () {
    const esc = (v) => $('<div>').text(v ?? '').html();
    const numberTr = (v) => Number(v || 0).toLocaleString('tr-TR');

    const endpoint = '../ajax/question-scope-bulk.php';
    const lookupEndpoint = '../ajax/questions.php';
    const mappingsPerPage = 50;
    let mappingsCache = [];
    let currentMappingsPage = 1;
    let mappingsPagination = {
        page: 1,
        per_page: mappingsPerPage,
        total: 0,
        total_pages: 0
    };
    let isAllMappingsSyncRunning = false;
    let stopAllMappingsSyncRequested = false;

    function appAlert(title, message, type = 'info') {
        if (typeof window.showAppAlert === 'function') {
            return window.showAppAlert({ title, message, type });
        }
        return Promise.resolve();
    }

    function appConfirm(opts) {
        if (typeof window.showAppConfirm === 'function') {
            return window.showAppConfirm(opts);
        }
        return Promise.resolve(false);
    }

    function parseRespError(resp, fallback = 'İşlem başarısız oldu.') {
        return (resp && resp.message) ? resp.message : fallback;
    }

    function getPayload() {
        return {
            source_qualification_id: $('#sourceQualification').val() || '',
            source_course_id: $('#sourceCourse').val() || '',
            source_topic_id: $('#sourceTopic').val() || '',
            question_type: $('#questionType').val() || '',
            search: $('#searchText').val().trim(),
            target_qualification_id: $('#targetQualification').val() || '',
            target_course_id: $('#targetCourse').val() || '',
            target_topic_id: $('#targetTopic').val() || ''
        };
    }

    function formatScope(qualificationName, courseName, topicName, emptyTopicLabel = 'Tüm konular') {
        const q = qualificationName || '-';
        const c = courseName || '-';
        const t = topicName || emptyTopicLabel;
        return '<div><strong>' + esc(q) + '</strong> / ' + esc(c) + '<br><span class="text-muted small">' + esc(t) + '</span></div>';
    }

    function formatDateTime(value) {
        if (!value) {
            return '<span class="text-muted">-</span>';
        }
        const dt = new Date(value.replace(' ', 'T'));
        if (Number.isNaN(dt.getTime())) {
            return esc(value);
        }
        return dt.toLocaleString('tr-TR');
    }

    function statusBadge(label) {
        const map = {
            'Güncel': 'bg-success-subtle text-success',
            'Güncelleme var': 'bg-warning-subtle text-warning-emphasis',
            'Kaynak boş': 'bg-secondary-subtle text-secondary'
            , 'Henüz kontrol edilmedi': 'bg-light text-dark'
            , 'Son kontrolde eksik var': 'bg-warning-subtle text-warning-emphasis'
            , 'Son kontrolde güncel': 'bg-success-subtle text-success'
        };
        const cls = map[label] || 'bg-light text-dark';
        return '<span class="badge rounded-pill ' + cls + '">' + esc(label || '-') + '</span>';
    }

    function renderFilter(mapping) {
        const parts = [];
        if (mapping.question_type) {
            parts.push('Tip: ' + mapping.question_type);
        }
        if (mapping.search_text) {
            parts.push('Arama: "' + mapping.search_text + '"');
        }
        if (!parts.length) {
            return '<span class="text-muted">Ek filtre yok</span>';
        }
        return '<span class="small">' + esc(parts.join(' • ')) + '</span>';
    }

    function getSelectedMappingIds() {
        return $('#mappingsTable tbody .mapping-check:checked').map(function () {
            return $(this).val();
        }).get();
    }

    function clearSelectedMappings() {
        $('#selectAllMappings').prop('checked', false);
        $('#mappingsTable tbody .mapping-check').prop('checked', false);
    }

    function setAllMappingsSyncControlsDisabled(disabled) {
        $('#syncAllMappingsBtn').prop('disabled', disabled);
        $('#bulkSyncMappingsBtn').prop('disabled', disabled);
        $('#bulkCancelMappingsBtn').prop('disabled', disabled);
        $('#refreshMappingsBtn').prop('disabled', disabled);
        $('.sync-mapping-btn').prop('disabled', disabled);
        $('.cancel-mapping-btn').prop('disabled', disabled);
    }

    function updateSyncAllProgress(processed, total, inserted, failed, statusMessage = '') {
        const safeTotal = Math.max(0, Number(total || 0));
        const safeProcessed = Math.max(0, Number(processed || 0));
        const percent = safeTotal > 0 ? Math.min(100, Math.round((safeProcessed / safeTotal) * 100)) : 0;

        $('#syncAllProgressText').text(
            'İşlenen: ' + numberTr(safeProcessed) + ' / ' + numberTr(safeTotal) +
            ' • Yeni eklenen: ' + numberTr(inserted) +
            ' • Hata: ' + numberTr(failed) +
            (statusMessage ? ' • ' + statusMessage : '')
        );
        $('#syncAllProgressBar')
            .css('width', percent + '%')
            .attr('aria-valuenow', percent)
            .text(percent + '%');
    }

    function setSyncAllProgressFinalState(state) {
        const $bar = $('#syncAllProgressBar');
        $bar.removeClass('progress-bar-animated progress-bar-striped bg-success bg-warning bg-danger');
        if (state === 'completed') {
            $bar.addClass('bg-success');
        } else if (state === 'stopped') {
            $bar.addClass('bg-warning');
        } else if (state === 'error') {
            $bar.addClass('bg-danger');
        }
    }

    function getMappingListFilters() {
        return {
            mapping_source_qualification_id: $('#mappingSourceQualificationFilter').val() || '',
            mapping_target_qualification_id: $('#mappingTargetQualificationFilter').val() || '',
            mapping_status: $('#mappingStatusFilter').val() || '',
            mapping_search: $('#mappingListSearch').val().trim()
        };
    }

    function hasMappingListFilters() {
        const filters = getMappingListFilters();
        return Object.values(filters).some((value) => String(value || '') !== '');
    }

    function clearMappingListFilters() {
        $('#mappingSourceQualificationFilter').val('');
        $('#mappingTargetQualificationFilter').val('');
        $('#mappingStatusFilter').val('');
        $('#mappingListSearch').val('');
        clearSelectedMappings();
    }

    function normalizePagination(pagination) {
        return {
            page: Math.max(1, Number(pagination?.page || 1)),
            per_page: Math.max(1, Number(pagination?.per_page || mappingsPerPage)),
            total: Math.max(0, Number(pagination?.total || 0)),
            total_pages: Math.max(0, Number(pagination?.total_pages || 0))
        };
    }

    function renderMappingsPagination(pagination) {
        mappingsPagination = normalizePagination(pagination);
        currentMappingsPage = mappingsPagination.page;

        const totalPagesForLabel = Math.max(1, mappingsPagination.total_pages);
        const totalLabel = hasMappingListFilters() ? 'Filtre sonucu ' : 'Toplam ';
        $('#mappingsPaginationInfo').text(
            'Sayfa ' + numberTr(mappingsPagination.page) + ' / ' + numberTr(totalPagesForLabel) +
            ' • ' + totalLabel + numberTr(mappingsPagination.total) + ' eşleştirme'
        );

        $('#prevMappingsPageBtn').prop('disabled', mappingsPagination.page <= 1);
        $('#nextMappingsPageBtn').prop('disabled', mappingsPagination.total_pages === 0 || mappingsPagination.page >= mappingsPagination.total_pages);
    }

    function renderMappingsTable(rows) {
        const $tbody = $('#mappingsTable tbody');

        if (!rows.length) {
            const emptyMessage = hasMappingListFilters()
                ? 'Seçilen filtrelere uygun kayıtlı eşleştirme bulunamadı.'
                : 'Kayıtlı eşleştirme bulunamadı.';
            $tbody.html('<tr><td colspan="10" class="text-muted">' + esc(emptyMessage) + '</td></tr>');
            clearSelectedMappings();
            return;
        }

        const html = rows.map((m) => {
            return '<tr data-id="' + esc(m.id) + '">' +
                '<td><input class="form-check-input mapping-check" type="checkbox" value="' + esc(m.id) + '"></td>' +
                '<td>' + formatScope(m.source_qualification_name, m.source_course_name, m.source_topic_name, 'Tüm konular') + '</td>' +
                '<td>' + formatScope(m.target_qualification_name, m.target_course_name, m.target_topic_name, 'Konu seçilmeden') + '</td>' +
                '<td>' + renderFilter(m) + '</td>' +
                '<td class="text-end">' + numberTr(m.source_count) + '</td>' +
                '<td class="text-end">' + numberTr(m.target_linked_count) + '</td>' +
                '<td class="text-end">' + numberTr(m.missing_count) + '</td>' +
                '<td>' + statusBadge(m.status_label) + '</td>' +
                '<td class="small">' + formatDateTime(m.last_synced_at) + '</td>' +
                '<td>' +
                    '<div class="btn-group btn-group-sm" role="group">' +
                        '<button class="btn btn-outline-primary sync-mapping-btn" data-id="' + esc(m.id) + '">Eşzamanla</button>' +
                        '<button class="btn btn-outline-danger cancel-mapping-btn" data-id="' + esc(m.id) + '">İptal Et</button>' +
                    '</div>' +
                '</td>' +
            '</tr>';
        });

        $tbody.html(html.join(''));
        if (isAllMappingsSyncRunning) {
            setAllMappingsSyncControlsDisabled(true);
        }
        clearSelectedMappings();
    }

    async function loadMappings(page = 1) {
        const requestedPage = Math.max(1, Number(page || 1));
        window.appSetButtonLoading('#refreshMappingsBtn', true, 'Yükleniyor...');
        const res = await window.appAjax({
            url: endpoint,
            method: 'GET',
            data: {
                action: 'mappings',
                page: requestedPage,
                per_page: mappingsPerPage,
                ...getMappingListFilters()
            },
            dataType: 'json'
        });
        window.appSetButtonLoading('#refreshMappingsBtn', false);

        if (!res.success) {
            await appAlert('Hata', parseRespError(res, 'Eşleştirme listesi alınamadı.'), 'error');
            return;
        }

        mappingsCache = res.data?.mappings || [];
        renderMappingsPagination(res.data?.pagination || {
            page: requestedPage,
            per_page: mappingsPerPage,
            total: mappingsCache.length,
            total_pages: mappingsCache.length ? 1 : 0
        });
        renderMappingsTable(mappingsCache);
    }

    async function syncSingleMapping(mappingId) {
        const confirmed = await appConfirm({
            title: 'Eşzamanla',
            message: 'Seçili kaynak-hedef eşleştirmesi için eksik bağlantılar eklenecek. Onaylıyor musunuz?',
            confirmText: 'Eşzamanla',
            cancelText: 'İptal',
            type: 'confirm'
        });

        if (!confirmed) {
            return;
        }

        const res = await window.appAjax({
            url: endpoint + '?action=sync_mapping',
            method: 'POST',
            data: { mapping_id: mappingId },
            dataType: 'json'
        });

        if (!res.success) {
            await appAlert('Hata', parseRespError(res, 'Eşzamanlama başarısız oldu.'), 'error');
            return;
        }

        const d = res.data || {};
        await appAlert('Başarılı',
            (res.message || 'Eşzamanlama tamamlandı.') +
            '\n\nKaynak: ' + numberTr(d.source_count) +
            '\nZaten bağlı: ' + numberTr(d.already_linked_count) +
            '\nYeni eklenen: ' + numberTr(d.inserted_count) +
            '\nKalan eksik: ' + numberTr(d.missing_count_after),
            'success'
        );
        await loadMappings(currentMappingsPage);
    }

    async function cancelSingleMapping(mappingId) {
        const confirmed = await appConfirm({
            title: 'Eşleştirmeyi İptal Et',
            message: 'Bu eşleştirme için hedefteki bağlantılar kaldırılacak (primary linkler korunur). Onaylıyor musunuz?',
            confirmText: 'İptal Et',
            cancelText: 'Vazgeç',
            type: 'warning'
        });

        if (!confirmed) {
            return;
        }

        const res = await window.appAjax({
            url: endpoint + '?action=cancel_mapping',
            method: 'POST',
            data: { mapping_id: mappingId },
            dataType: 'json'
        });

        if (!res.success) {
            await appAlert('Hata', parseRespError(res, 'İptal işlemi başarısız oldu.'), 'error');
            return;
        }

        const d = res.data || {};
        await appAlert('Başarılı',
            (res.message || 'İptal işlemi tamamlandı.') +
            '\n\nEşleşen link: ' + numberTr(d.matched_links) +
            '\nSilinen: ' + numberTr(d.deleted_count) +
            '\nAtlanan primary: ' + numberTr(d.skipped_primary_count),
            'success'
        );
        await loadMappings(currentMappingsPage);
    }

    async function bulkSyncMappings(ids) {
        const confirmed = await appConfirm({
            title: 'Toplu Eşzamanla',
            message: 'Seçilen eşleştirmelerde eksik bağlantılar eklenecek. Onaylıyor musunuz?',
            confirmText: 'Toplu Eşzamanla',
            cancelText: 'İptal',
            type: 'confirm'
        });
        if (!confirmed) {
            return;
        }

        window.appSetButtonLoading('#bulkSyncMappingsBtn', true, 'İşleniyor...');
        const res = await window.appAjax({
            url: endpoint + '?action=bulk_sync_mappings',
            method: 'POST',
            data: { ids },
            dataType: 'json'
        });
        window.appSetButtonLoading('#bulkSyncMappingsBtn', false);

        if (!res.success) {
            await appAlert('Hata', parseRespError(res, 'Toplu eşzamanlama başarısız oldu.'), 'error');
            return;
        }

        const d = res.data || {};
        await appAlert('Başarılı',
            (res.message || 'Toplu eşzamanlama tamamlandı.') +
            '\n\nİşlenen: ' + numberTr(d.processed) +
            '\nToplam eklenen: ' + numberTr(d.total_inserted) +
            '\nHatalı: ' + numberTr(d.failed),
            'success'
        );
        await loadMappings(currentMappingsPage);
    }

    async function bulkCancelMappings(ids) {
        const confirmed = await appConfirm({
            title: 'Toplu İptal',
            message: 'Seçilen eşleştirmelerin hedef bağlantıları kaldırılacak (primary korunur). Onaylıyor musunuz?',
            confirmText: 'Toplu İptal Et',
            cancelText: 'Vazgeç',
            type: 'warning'
        });
        if (!confirmed) {
            return;
        }

        window.appSetButtonLoading('#bulkCancelMappingsBtn', true, 'İşleniyor...');
        const res = await window.appAjax({
            url: endpoint + '?action=bulk_cancel_mappings',
            method: 'POST',
            data: { ids },
            dataType: 'json'
        });
        window.appSetButtonLoading('#bulkCancelMappingsBtn', false);

        if (!res.success) {
            await appAlert('Hata', parseRespError(res, 'Toplu iptal başarısız oldu.'), 'error');
            return;
        }

        const d = res.data || {};
        await appAlert('Başarılı',
            (res.message || 'Toplu iptal tamamlandı.') +
            '\n\nİşlenen: ' + numberTr(d.processed) +
            '\nToplam silinen: ' + numberTr(d.total_removed) +
            '\nHatalı: ' + numberTr(d.failed),
            'success'
        );
        await loadMappings(currentMappingsPage);
    }

    async function syncAllMappings() {
        if (isAllMappingsSyncRunning) {
            return;
        }

        const confirmed = await appConfirm({
            title: 'Tümünü Eşzamanla',
            message: 'Tüm kayıtlı eşleştirmeler sırayla kontrol edilip eksik bağlantılar eklenecek. İşlem uzun sürebilir. Devam etmek istiyor musunuz?',
            confirmText: 'Tümünü Eşzamanla',
            cancelText: 'İptal',
            type: 'confirm'
        });
        if (!confirmed) {
            return;
        }

        isAllMappingsSyncRunning = true;
        stopAllMappingsSyncRequested = false;

        let cursor = '';
        let totalMappings = 0;
        let processedTotal = 0;
        let insertedTotal = 0;
        let failedTotal = 0;
        let stoppedByUser = false;

        $('#syncAllProgressBox').removeClass('d-none');
        $('#syncAllStopBtn').prop('disabled', false).html('<i class="bi bi-stop-circle"></i> Durdur');
        $('#syncAllProgressBar')
            .removeClass('bg-success bg-warning bg-danger')
            .addClass('progress-bar-striped progress-bar-animated')
            .css('width', '0%')
            .attr('aria-valuenow', 0)
            .text('0%');
        updateSyncAllProgress(0, 0, 0, 0, 'Başlatılıyor...');
        setAllMappingsSyncControlsDisabled(true);
        window.appSetButtonLoading('#syncAllMappingsBtn', true, 'Eşzamanlanıyor...');

        try {
            while (true) {
                const res = await window.appAjax({
                    url: endpoint + '?action=sync_all_mappings_batch',
                    method: 'POST',
                    data: {
                        cursor,
                        batch_size: 5
                    },
                    dataType: 'json'
                });

                if (!res.success) {
                    throw new Error(parseRespError(res, 'Batch eşzamanlama başarısız oldu.'));
                }

                const d = res.data || {};
                if (d.total_mappings !== null && d.total_mappings !== undefined) {
                    totalMappings = Number(d.total_mappings || 0);
                }

                processedTotal += Number(d.processed || 0) + Number(d.failed || 0);
                insertedTotal += Number(d.total_inserted || 0);
                failedTotal += Number(d.failed || 0);
                cursor = d.next_cursor || cursor;

                updateSyncAllProgress(processedTotal, totalMappings, insertedTotal, failedTotal);

                if (stopAllMappingsSyncRequested) {
                    stoppedByUser = true;
                    updateSyncAllProgress(processedTotal, totalMappings, insertedTotal, failedTotal, 'Kullanıcı tarafından durduruldu.');
                    break;
                }

                if (!d.has_more) {
                    break;
                }
            }

            setSyncAllProgressFinalState(stoppedByUser ? 'stopped' : 'completed');
            $('#syncAllStopBtn').prop('disabled', true);
            updateSyncAllProgress(
                processedTotal,
                totalMappings,
                insertedTotal,
                failedTotal,
                stoppedByUser ? 'Durduruldu.' : 'Tamamlandı.'
            );

            await appAlert(
                stoppedByUser ? 'İşlem Durduruldu' : 'Başarılı',
                (stoppedByUser ? 'İşlem kullanıcı tarafından durduruldu.' : 'Tümünü eşzamanlama tamamlandı.') +
                '\n\nİşlenen: ' + numberTr(processedTotal) +
                '\nYeni eklenen: ' + numberTr(insertedTotal) +
                '\nHata: ' + numberTr(failedTotal),
                stoppedByUser ? 'warning' : 'success'
            );
        } catch (error) {
            setSyncAllProgressFinalState('error');
            $('#syncAllStopBtn').prop('disabled', true);
            updateSyncAllProgress(processedTotal, totalMappings, insertedTotal, failedTotal, 'Hata nedeniyle durdu.');
            await appAlert('Hata', error?.message || 'Tümünü eşzamanlama sırasında hata oluştu.', 'error');
        } finally {
            isAllMappingsSyncRunning = false;
            stopAllMappingsSyncRequested = false;
            window.appSetButtonLoading('#syncAllMappingsBtn', false);
            setAllMappingsSyncControlsDisabled(false);
            await loadMappings(currentMappingsPage);
        }
    }

    function validatePayload(payload) {
        if (!payload.source_qualification_id || !payload.source_course_id) {
            return 'Kaynak yeterlilik ve kaynak ders seçilmelidir.';
        }
        if (!payload.target_qualification_id || !payload.target_course_id) {
            return 'Hedef yeterlilik ve hedef ders seçilmelidir.';
        }

        if (
            payload.source_qualification_id === payload.target_qualification_id &&
            payload.source_course_id === payload.target_course_id &&
            (payload.source_topic_id || '') === (payload.target_topic_id || '')
        ) {
            return 'Kaynak ve hedef kapsam aynı olamaz.';
        }

        return '';
    }

    function setTopicDisabled($select, disabled, emptyLabel = 'Tüm konular') {
        $select.prop('disabled', disabled);
        if (disabled) {
            $select.html('<option value="">' + esc(emptyLabel) + '</option>');
        }
    }

    async function loadQualifications() {
        const res = await window.appAjax({
            url: lookupEndpoint + '?action=list_qualifications',
            method: 'GET',
            dataType: 'json'
        });

        if (!res.success) {
            await appAlert('Hata', parseRespError(res, 'Yeterlilikler yüklenemedi.'), 'error');
            return;
        }

        const rows = res.data?.qualifications || [];
        const options = ['<option value="">Seçiniz...</option>'];
        rows.forEach((r) => options.push('<option value="' + esc(r.id) + '">' + esc(r.name) + '</option>'));

        $('#sourceQualification').html(options.join(''));
        $('#targetQualification').html(options.join(''));

        const sourceFilterOptions = ['<option value="">Tüm kaynak yeterlilikler</option>'];
        const targetFilterOptions = ['<option value="">Tüm hedef yeterlilikler</option>'];
        rows.forEach((r) => {
            sourceFilterOptions.push('<option value="' + esc(r.id) + '">' + esc(r.name) + '</option>');
            targetFilterOptions.push('<option value="' + esc(r.id) + '">' + esc(r.name) + '</option>');
        });

        $('#mappingSourceQualificationFilter').html(sourceFilterOptions.join(''));
        $('#mappingTargetQualificationFilter').html(targetFilterOptions.join(''));
    }

    async function loadCourses(qualificationId, $courseSelect, $topicSelect, topicEmptyLabel) {
        $courseSelect.prop('disabled', true).html('<option value="">Yükleniyor...</option>');
        setTopicDisabled($topicSelect, true, topicEmptyLabel);

        if (!qualificationId) {
            $courseSelect.html('<option value="">Önce yeterlilik seçin...</option>');
            return;
        }

        const res = await window.appAjax({
            url: lookupEndpoint + '?action=list_courses',
            method: 'GET',
            data: { qualification_id: qualificationId },
            dataType: 'json'
        });

        if (!res.success) {
            $courseSelect.html('<option value="">Dersler yüklenemedi</option>');
            return;
        }

        const rows = res.data?.courses || [];
        const options = ['<option value="">Seçiniz...</option>'];
        rows.forEach((r) => options.push('<option value="' + esc(r.id) + '">' + esc(r.name) + '</option>'));
        $courseSelect.html(options.join('')).prop('disabled', false);
    }

    async function loadTopics(courseId, $topicSelect, emptyLabel) {
        $topicSelect.prop('disabled', true).html('<option value="">Yükleniyor...</option>');

        if (!courseId) {
            $topicSelect.html('<option value="">' + esc(emptyLabel) + '</option>');
            return;
        }

        const res = await window.appAjax({
            url: lookupEndpoint + '?action=list_topics',
            method: 'GET',
            data: { course_id: courseId },
            dataType: 'json'
        });

        if (!res.success) {
            $topicSelect.html('<option value="">Konular yüklenemedi</option>');
            return;
        }

        const rows = res.data?.topics || [];
        const options = ['<option value="">' + esc(emptyLabel) + '</option>'];
        rows.forEach((r) => options.push('<option value="' + esc(r.id) + '">' + esc(r.name) + '</option>'));
        $topicSelect.html(options.join('')).prop('disabled', rows.length === 0);
    }

    function renderPreview(data) {
        const summary = data.summary || {};
        const samples = data.sample_questions || [];

        $('#pvTotal').text(numberTr(summary.total_source_questions));
        $('#pvAlready').text(numberTr(summary.already_linked_count));
        $('#pvWillAdd').text(numberTr(summary.will_add_count));
        $('#pvPrimary').text(numberTr(summary.primary_count));

        const $tbody = $('#sampleTable tbody');
        if (!samples.length) {
            $tbody.html('<tr><td colspan="2" class="text-muted">Örnek soru bulunamadı.</td></tr>');
        } else {
            const rows = samples.map((q) => {
                return '<tr>' +
                    '<td class="small text-muted">' + esc((q.id || '').slice(0, 12)) + '...</td>' +
                    '<td>' + esc(q.question_text || '').slice(0, 240) + '</td>' +
                '</tr>';
            });
            $tbody.html(rows.join(''));
        }

        $('#previewBox').removeClass('d-none');
    }

    async function doPreview() {
        const payload = getPayload();
        const validationError = validatePayload(payload);
        if (validationError) {
            await appAlert('Uyarı', validationError, 'warning');
            return null;
        }

        window.appSetButtonLoading('#previewBtn', true, 'Önizleniyor...');
        const res = await window.appAjax({
            url: endpoint + '?action=preview',
            method: 'POST',
            data: payload,
            dataType: 'json'
        });
        window.appSetButtonLoading('#previewBtn', false);

        if (!res.success) {
            await appAlert('Hata', parseRespError(res, 'Önizleme alınamadı.'), 'error');
            return null;
        }

        renderPreview(res.data || {});
        return res.data || null;
    }

    async function doBulkAction(action) {
        const payload = getPayload();
        const validationError = validatePayload(payload);
        if (validationError) {
            await appAlert('Uyarı', validationError, 'warning');
            return;
        }

        const isAdd = action === 'bulk_add';
        const confirmed = await appConfirm({
            title: isAdd ? 'Toplu Kapsam Ekle' : 'Toplu Kapsam Kaldır',
            message: isAdd
                ? 'Seçili filtreye uyan sorulara hedef kapsam eklenecek. Onaylıyor musunuz?'
                : 'Seçili filtredeki soruların hedef kapsam bağlantıları kaldırılacak (primary hariç). Onaylıyor musunuz?',
            confirmText: isAdd ? 'Ekle' : 'Kaldır',
            cancelText: 'İptal',
            type: isAdd ? 'confirm' : 'warning'
        });

        if (!confirmed) {
            return;
        }

        const btnId = isAdd ? '#bulkAddBtn' : '#bulkRemoveBtn';
        window.appSetButtonLoading(btnId, true, 'İşleniyor...');

        const res = await window.appAjax({
            url: endpoint + '?action=' + action,
            method: 'POST',
            data: payload,
            dataType: 'json'
        });

        window.appSetButtonLoading(btnId, false);

        if (!res.success) {
            await appAlert('Hata', parseRespError(res, 'Toplu işlem başarısız oldu.'), 'error');
            return;
        }

        const d = res.data || {};
        let detailMessage = '';
        if (isAdd) {
            detailMessage = 'Toplam kaynak: ' + numberTr(d.total_source_questions) +
                '\nYeni eklenen: ' + numberTr(d.inserted_count) +
                '\nAtlanan (zaten vardı): ' + numberTr(d.skipped_existing_count);
        } else {
            detailMessage = 'Eşleşen link: ' + numberTr(d.matched_links) +
                '\nSilinen: ' + numberTr(d.deleted_count) +
                '\nAtlanan primary: ' + numberTr(d.skipped_primary_count);
        }

        await appAlert('Başarılı', (res.message || 'İşlem tamamlandı.') + '\n\n' + detailMessage, 'success');
        await doPreview();
        await loadMappings(currentMappingsPage);
    }

    $('#sourceQualification').on('change', function () {
        loadCourses($(this).val(), $('#sourceCourse'), $('#sourceTopic'), 'Tüm konular');
    });

    $('#sourceCourse').on('change', function () {
        loadTopics($(this).val(), $('#sourceTopic'), 'Tüm konular');
    });

    $('#targetQualification').on('change', function () {
        loadCourses($(this).val(), $('#targetCourse'), $('#targetTopic'), 'Konu seçmeden devam et');
    });

    $('#targetCourse').on('change', function () {
        loadTopics($(this).val(), $('#targetTopic'), 'Konu seçmeden devam et');
    });

    $('#previewBtn').on('click', async function () {
        await doPreview();
    });

    $('#bulkAddBtn').on('click', async function () {
        await doBulkAction('bulk_add');
    });

    $('#bulkRemoveBtn').on('click', async function () {
        await doBulkAction('bulk_remove');
    });

    $('#refreshMappingsBtn').on('click', async function () {
        if (isAllMappingsSyncRunning) {
            return;
        }
        await loadMappings(currentMappingsPage);
    });

    $('#syncAllMappingsBtn').on('click', async function () {
        await syncAllMappings();
    });

    $('#syncAllStopBtn').on('click', function () {
        if (!isAllMappingsSyncRunning) {
            return;
        }
        stopAllMappingsSyncRequested = true;
        $(this).prop('disabled', true).html('<i class="bi bi-hourglass-split"></i> Durdurulacak');
        $('#syncAllProgressText').text($('#syncAllProgressText').text() + ' • Mevcut batch tamamlandıktan sonra işlem durdurulacak.');
    });

    $('#filterMappingsBtn').on('click', async function () {
        clearSelectedMappings();
        await loadMappings(1);
    });

    $('#clearMappingsFiltersBtn').on('click', async function () {
        clearMappingListFilters();
        await loadMappings(1);
    });

    $('#mappingListSearch').on('keydown', async function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            clearSelectedMappings();
            await loadMappings(1);
        }
    });

    $('#prevMappingsPageBtn').on('click', async function () {
        if (currentMappingsPage > 1) {
            await loadMappings(currentMappingsPage - 1);
        }
    });

    $('#nextMappingsPageBtn').on('click', async function () {
        if (mappingsPagination.total_pages > 0 && currentMappingsPage < mappingsPagination.total_pages) {
            await loadMappings(currentMappingsPage + 1);
        }
    });

    $('#selectAllMappings').on('change', function () {
        const checked = $(this).is(':checked');
        $('#mappingsTable tbody .mapping-check').prop('checked', checked);
    });

    $(document).on('change', '#mappingsTable tbody .mapping-check', function () {
        const total = $('#mappingsTable tbody .mapping-check').length;
        const checked = $('#mappingsTable tbody .mapping-check:checked').length;
        $('#selectAllMappings').prop('checked', total > 0 && total === checked);
    });

    $(document).on('click', '.sync-mapping-btn', async function () {
        if (isAllMappingsSyncRunning) {
            return;
        }
        const id = $(this).data('id') || '';
        if (id) {
            await syncSingleMapping(id);
        }
    });

    $(document).on('click', '.cancel-mapping-btn', async function () {
        if (isAllMappingsSyncRunning) {
            return;
        }
        const id = $(this).data('id') || '';
        if (id) {
            await cancelSingleMapping(id);
        }
    });

    $('#bulkSyncMappingsBtn').on('click', async function () {
        if (isAllMappingsSyncRunning) {
            return;
        }
        const ids = getSelectedMappingIds();
        if (!ids.length) {
            await appAlert('Uyarı', 'Lütfen eşzamanlamak için en az bir kayıt seçin.', 'warning');
            return;
        }
        await bulkSyncMappings(ids);
    });

    $('#bulkCancelMappingsBtn').on('click', async function () {
        if (isAllMappingsSyncRunning) {
            return;
        }
        const ids = getSelectedMappingIds();
        if (!ids.length) {
            await appAlert('Uyarı', 'Lütfen iptal etmek için en az bir kayıt seçin.', 'warning');
            return;
        }
        await bulkCancelMappings(ids);
    });

    loadQualifications();
    loadMappings(1);
});
</script>
JS;

include '../includes/footer.php';

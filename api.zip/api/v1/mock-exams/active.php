<?php

require_once dirname(__DIR__) . '/api_bootstrap.php';
require_once dirname(__DIR__) . '/auth_helper.php';
require_once dirname(__DIR__) . '/response_helper.php';
require_once dirname(__DIR__) . '/mock_exam_helper.php';

api_require_method('GET');

try {
    $auth = api_require_auth($pdo);
    $userId = (string)$auth['user']['id'];

    $detail = mock_exam_fetch_active_attempt_detail($pdo, $userId);
    if (!$detail) {
        api_success('Aktif deneme yok.', [
            'attempt' => null,
            'questions' => [],
            'summary' => null,
            'lesson_report' => [],
            'strongest_course' => null,
            'weakest_course' => null,
            'most_blank_course' => null,
        ]);
    }

    $questions = $detail['questions'] ?? [];
    if (empty($questions)) {
        api_error('Bu kriterlere uygun deneme soruları oluşturulamadı.', 422);
    }

    api_success('Aktif deneme detayı alındı.', [
        'attempt' => $detail['attempt'] ?? null,
        'questions' => $questions,
        'summary' => $detail['summary'] ?? null,
        'lesson_report' => $detail['lesson_report'] ?? [],
        'strongest_course' => $detail['strongest_course'] ?? null,
        'weakest_course' => $detail['weakest_course'] ?? null,
        'most_blank_course' => $detail['most_blank_course'] ?? null,
    ]);
} catch (Throwable $e) {
    api_error($e->getMessage(), 422);
}

$(document).ajaxError(function (event, jqxhr, settings, thrownError) {
    console.error('AJAX Error:', thrownError);
    if (typeof window.showAppAlert === 'function') {
        window.showAppAlert({
            title: 'Hata',
            message: 'Bir hata oluştu: ' + thrownError,
            type: 'error',
        });
    }
});

function showToast(message, type = 'success') {
    const toast = `
        <div class="toast align-items-center text-white bg-${type} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;

    const container = $('#toast-container');
    if (!container.length) {
        $('body').append('<div id="toast-container" class="position-fixed top-0 end-0 p-3" style="z-index: 9999"></div>');
    }

    $('#toast-container').append(toast);
    $('.toast').toast({ delay: 3000 }).toast('show');
}

function confirmAction(message, callback) {
    if (typeof window.showAppConfirm === 'function') {
        window.showAppConfirm({
            title: 'Onay',
            message: message,
            onConfirm: callback,
        });
        return;
    }
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('tr-TR', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
    });
}

(function initAppDialogs() {
    let activeResolver = null;
    let activeOnConfirm = null;
    let activeOnCancel = null;
    let activeMode = 'alert';
    let actionTaken = false;

    function ensureDialogMarkup() {
        let modal = document.getElementById('appDialogModal');
        if (modal) return modal;

        const wrapper = document.createElement('div');
        wrapper.innerHTML = `
            <div class="modal fade" id="appDialogModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header bg-info text-white">
                            <h5 class="modal-title" id="appDialogTitle">Bilgi</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body" id="appDialogBody"></div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" id="appDialogCancelBtn" data-bs-dismiss="modal">İptal</button>
                            <button type="button" class="btn btn-primary" id="appDialogConfirmBtn">Tamam</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(wrapper.firstElementChild);
        return document.getElementById('appDialogModal');
    }

    function getEls() {
        const modal = ensureDialogMarkup();
        return {
            modal,
            title: document.getElementById('appDialogTitle'),
            body: document.getElementById('appDialogBody'),
            cancel: document.getElementById('appDialogCancelBtn'),
            confirm: document.getElementById('appDialogConfirmBtn'),
        };
    }

    function safeHtml(text) {
        return (text || '').toString().replace(/\n/g, '<br>');
    }

    function setType(modalEl, type) {
        const header = modalEl.querySelector('.modal-header');
        const confirmBtn = modalEl.querySelector('#appDialogConfirmBtn');
        header.classList.remove('bg-danger', 'bg-success', 'bg-warning', 'bg-info', 'text-white', 'text-dark');
        confirmBtn.classList.remove('btn-danger', 'btn-success', 'btn-warning', 'btn-primary');

        if (type === 'error') {
            header.classList.add('bg-danger', 'text-white');
            confirmBtn.classList.add('btn-danger');
        } else if (type === 'success') {
            header.classList.add('bg-success', 'text-white');
            confirmBtn.classList.add('btn-success');
        } else if (type === 'warning' || type === 'confirm') {
            header.classList.add('bg-warning', 'text-dark');
            confirmBtn.classList.add('btn-warning');
        } else {
            header.classList.add('bg-info', 'text-white');
            confirmBtn.classList.add('btn-primary');
        }
    }

    function resetDialogState() {
        activeResolver = null;
        activeOnConfirm = null;
        activeOnCancel = null;
        activeMode = 'alert';
        actionTaken = false;
    }

    function normalizeAlertArgs(arg1, arg2, arg3) {
        if (typeof arg1 === 'object' && arg1 !== null) {
            return {
                title: arg1.title || 'Bilgi',
                message: arg1.message || '',
                type: arg1.type || 'info',
                buttonText: arg1.buttonText || 'Tamam',
            };
        }

        return {
            title: arg1 || 'Bilgi',
            message: arg2 || '',
            type: arg3 || 'info',
            buttonText: 'Tamam',
        };
    }

    function normalizeConfirmArgs(arg1, arg2, arg3, arg4) {
        if (typeof arg1 === 'object' && arg1 !== null) {
            return {
                title: arg1.title || 'Onay',
                message: arg1.message || '',
                onConfirm: typeof arg1.onConfirm === 'function' ? arg1.onConfirm : null,
                onCancel: typeof arg1.onCancel === 'function' ? arg1.onCancel : null,
                type: arg1.type || 'warning',
                confirmText: arg1.confirmText || 'Onayla',
                cancelText: arg1.cancelText || 'İptal',
            };
        }

        const options = (arg4 && typeof arg4 === 'object') ? arg4 : {};
        return {
            title: arg1 || 'Onay',
            message: arg2 || '',
            onConfirm: typeof arg3 === 'function' ? arg3 : null,
            onCancel: typeof options.onCancel === 'function' ? options.onCancel : null,
            type: options.type || 'warning',
            confirmText: options.confirmText || 'Onayla',
            cancelText: options.cancelText || 'İptal',
        };
    }

    window.showAppAlert = function (arg1, arg2, arg3) {
        const els = getEls();
        if (!els.modal || typeof bootstrap === 'undefined') {
            return Promise.resolve();
        }

        const config = normalizeAlertArgs(arg1, arg2, arg3);
        const modal = bootstrap.Modal.getOrCreateInstance(els.modal);

        resetDialogState();
        activeMode = 'alert';

        els.title.textContent = config.title;
        els.body.innerHTML = safeHtml(config.message);
        els.cancel.classList.add('d-none');
        els.confirm.textContent = config.buttonText;
        setType(els.modal, config.type);

        return new Promise((resolve) => {
            activeResolver = resolve;

            els.confirm.onclick = function () {
                actionTaken = true;
                if (activeResolver) {
                    activeResolver();
                }
                modal.hide();
            };

            els.cancel.onclick = null;

            els.modal.addEventListener('hidden.bs.modal', function onHidden() {
                els.modal.removeEventListener('hidden.bs.modal', onHidden);
                resetDialogState();
                els.confirm.onclick = null;
                els.cancel.onclick = null;
            });

            modal.show();
        });
    };

    window.showAppConfirm = function (arg1, arg2, arg3, arg4) {
        const els = getEls();
        if (!els.modal || typeof bootstrap === 'undefined') {
            return Promise.resolve(false);
        }

        const config = normalizeConfirmArgs(arg1, arg2, arg3, arg4);
        const modal = bootstrap.Modal.getOrCreateInstance(els.modal);

        resetDialogState();
        activeMode = 'confirm';
        activeOnConfirm = config.onConfirm;
        activeOnCancel = config.onCancel;

        els.title.textContent = config.title;
        els.body.innerHTML = safeHtml(config.message);
        els.cancel.classList.remove('d-none');
        els.cancel.textContent = config.cancelText;
        els.confirm.textContent = config.confirmText;
        setType(els.modal, config.type || 'confirm');

        return new Promise((resolve) => {
            activeResolver = resolve;

            els.confirm.onclick = function () {
                actionTaken = true;
                const onConfirmCb = activeOnConfirm;
                if (typeof onConfirmCb === 'function') {
                    onConfirmCb();
                }
                if (activeResolver) {
                    activeResolver(true);
                }
                modal.hide();
            };

            els.cancel.onclick = function () {
                actionTaken = false;
                const onCancelCb = activeOnCancel;
                if (typeof onCancelCb === 'function') {
                    onCancelCb();
                }
                if (activeResolver) {
                    activeResolver(false);
                }
                modal.hide();
            };

            els.modal.addEventListener('hidden.bs.modal', function onHidden() {
                els.modal.removeEventListener('hidden.bs.modal', onHidden);
                resetDialogState();
                els.confirm.onclick = null;
                els.cancel.onclick = null;
            });

            modal.show();
        });
    };
})();

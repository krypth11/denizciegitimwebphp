<?php
header('Content-Type: application/json; charset=utf-8');

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

$user = require_admin();
$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    $questionCols = get_table_columns($pdo, 'questions');
    $hasOptionE = is_array($questionCols) && in_array('option_e', $questionCols, true);

    switch ($action) {
        case 'add':
            $course_id = $_POST['course_id'] ?? '';
            $question_type = $_POST['question_type'] ?? '';
            $question_text = sanitize_input($_POST['question_text'] ?? '');
            $option_a = sanitize_input($_POST['option_a'] ?? '');
            $option_b = sanitize_input($_POST['option_b'] ?? '');
            $option_c = sanitize_input($_POST['option_c'] ?? '');
            $option_d = sanitize_input($_POST['option_d'] ?? '');
            $option_e = sanitize_input($_POST['option_e'] ?? '');
            $correct_answer = strtoupper(trim((string)($_POST['correct_answer'] ?? '')));
            $explanation = sanitize_input($_POST['explanation'] ?? '');

            if (empty($course_id) || empty($question_type) || empty($question_text) ||
                empty($option_a) || empty($option_b) || empty($option_c) ||
                empty($option_d) || empty($correct_answer)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Tüm zorunlu alanları doldurun!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if (!in_array($question_type, ['sayısal', 'sözel'], true)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Geçersiz soru tipi!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if (!in_array($correct_answer, ['A', 'B', 'C', 'D', 'E'], true)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Geçersiz doğru cevap!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if ($correct_answer === 'E' && $option_e === '') {
                echo json_encode([
                    'success' => false,
                    'message' => 'E doğru cevap için Şık E doldurulmalıdır!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $id = generate_uuid();

            if ($hasOptionE) {
                $stmt = $pdo->prepare(
                    'INSERT INTO questions (
                        id, course_id, question_type, question_text,
                        option_a, option_b, option_c, option_d, option_e,
                        correct_answer, explanation, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())'
                );
                $ok = $stmt->execute([
                    $id, $course_id, $question_type, $question_text,
                    $option_a, $option_b, $option_c, $option_d, ($option_e !== '' ? $option_e : null),
                    $correct_answer, $explanation,
                ]);
            } else {
                $stmt = $pdo->prepare(
                    'INSERT INTO questions (
                        id, course_id, question_type, question_text,
                        option_a, option_b, option_c, option_d,
                        correct_answer, explanation, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())'
                );
                $ok = $stmt->execute([
                    $id, $course_id, $question_type, $question_text,
                    $option_a, $option_b, $option_c, $option_d,
                    $correct_answer, $explanation,
                ]);
            }

            if ($ok) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Soru başarıyla eklendi!',
                    'data' => ['id' => $id],
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Veritabanı hatası!',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'get':
            $id = $_GET['id'] ?? '';

            if (empty($id)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'ID gerekli!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $stmt = $pdo->prepare('SELECT * FROM questions WHERE id = ?');
            $stmt->execute([$id]);
            $data = $stmt->fetch();

            if ($data) {
                echo json_encode([
                    'success' => true,
                    'data' => $data,
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Soru bulunamadı!',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'update':
            $id = $_POST['id'] ?? '';
            $course_id = $_POST['course_id'] ?? '';
            $question_type = $_POST['question_type'] ?? '';
            $question_text = sanitize_input($_POST['question_text'] ?? '');
            $option_a = sanitize_input($_POST['option_a'] ?? '');
            $option_b = sanitize_input($_POST['option_b'] ?? '');
            $option_c = sanitize_input($_POST['option_c'] ?? '');
            $option_d = sanitize_input($_POST['option_d'] ?? '');
            $option_e = sanitize_input($_POST['option_e'] ?? '');
            $correct_answer = strtoupper(trim((string)($_POST['correct_answer'] ?? '')));
            $explanation = sanitize_input($_POST['explanation'] ?? '');

            if (empty($id)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'ID gerekli!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if (empty($course_id) || empty($question_type) || empty($question_text) ||
                empty($option_a) || empty($option_b) || empty($option_c) ||
                empty($option_d) || empty($correct_answer)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Tüm zorunlu alanları doldurun!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if (!in_array($question_type, ['sayısal', 'sözel'], true)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Geçersiz soru tipi!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if (!in_array($correct_answer, ['A', 'B', 'C', 'D', 'E'], true)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Geçersiz doğru cevap!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if ($correct_answer === 'E' && $option_e === '') {
                echo json_encode([
                    'success' => false,
                    'message' => 'E doğru cevap için Şık E doldurulmalıdır!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            if ($hasOptionE) {
                $stmt = $pdo->prepare(
                    'UPDATE questions SET
                        course_id = ?,
                        question_type = ?,
                        question_text = ?,
                        option_a = ?,
                        option_b = ?,
                        option_c = ?,
                        option_d = ?,
                        option_e = ?,
                        correct_answer = ?,
                        explanation = ?
                    WHERE id = ?'
                );
                $ok = $stmt->execute([
                    $course_id, $question_type, $question_text,
                    $option_a, $option_b, $option_c, $option_d, ($option_e !== '' ? $option_e : null),
                    $correct_answer, $explanation, $id,
                ]);
            } else {
                $stmt = $pdo->prepare(
                    'UPDATE questions SET
                        course_id = ?,
                        question_type = ?,
                        question_text = ?,
                        option_a = ?,
                        option_b = ?,
                        option_c = ?,
                        option_d = ?,
                        correct_answer = ?,
                        explanation = ?
                    WHERE id = ?'
                );
                $ok = $stmt->execute([
                    $course_id, $question_type, $question_text,
                    $option_a, $option_b, $option_c, $option_d,
                    $correct_answer, $explanation, $id,
                ]);
            }

            if ($ok) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Soru güncellendi!',
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Güncelleme başarısız!',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'delete':
            $id = $_POST['id'] ?? '';

            if (empty($id)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'ID gerekli!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $stmt = $pdo->prepare('DELETE FROM questions WHERE id = ?');

            if ($stmt->execute([$id])) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Soru silindi!',
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Silme başarısız!',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        case 'bulk_delete':
            $ids = $_POST['ids'] ?? [];

            if (empty($ids) || !is_array($ids)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Silinecek soru seçilmedi!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $valid_ids = array_values(array_filter($ids, static function ($id) {
                return !empty($id) && strlen((string)$id) === 36;
            }));

            if (empty($valid_ids)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Geçersiz ID listesi!',
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $placeholders = implode(',', array_fill(0, count($valid_ids), '?'));
            $stmt = $pdo->prepare("DELETE FROM questions WHERE id IN ($placeholders)");

            if ($stmt->execute($valid_ids)) {
                $deleted = $stmt->rowCount();
                echo json_encode([
                    'success' => true,
                    'message' => $deleted . ' soru başarıyla silindi!',
                ], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Silme işlemi başarısız!',
                ], JSON_UNESCAPED_UNICODE);
            }
            break;

        default:
            echo json_encode([
                'success' => false,
                'message' => 'Geçersiz işlem!',
            ], JSON_UNESCAPED_UNICODE);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'İşlem sırasında bir sunucu hatası oluştu.',
    ], JSON_UNESCAPED_UNICODE);
}
